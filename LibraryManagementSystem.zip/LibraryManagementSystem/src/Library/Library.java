package Library;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class Library {

    private Connection conn;

    // Constructor to initialize the database connection
    public Library() {
        try {
            // Connect to MySQL database (make sure MySQL JDBC driver is in classpath)
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/library", "root", "Mahi@160504");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Add new book
    public boolean addBook(Book book) {
        String query = "INSERT INTO books (title, author, isbn) VALUES (?, ?, ?)";
        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, book.getTitle());
            stmt.setString(2, book.getAuthor());
            stmt.setString(3, book.getIsbn());
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Add new member
    public boolean addMember(Member member) {
        String query = "INSERT INTO members (name, email) VALUES (?, ?)";
        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, member.getName());
            stmt.setString(2, member.getEmail());
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Issue a book to a member
    public boolean issueBook(int bookId, int memberId) {
        // First, check if the book is available (not already issued)
        if (!isBookAvailable(bookId)) {
            System.out.println("Book is not available for issuing.");
            return false;
        }

        String query = "INSERT INTO issued_books (book_id, member_id, issue_date) VALUES (?, ?, CURDATE())";
        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, bookId);
            stmt.setInt(2, memberId);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Return a book
    public boolean returnBook(int bookId, int memberId) {
        String query = "UPDATE issued_books SET return_date = CURDATE() WHERE book_id = ? AND member_id = ? AND return_date IS NULL";
        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, bookId);
            stmt.setInt(2, memberId);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Get list of books issued to a member
    public List<String> getBooksIssuedToMember(int memberId) {
        List<String> bookTitles = new ArrayList<>();
        String query = "SELECT b.title FROM books b "
                + "JOIN issued_books ib ON b.book_id = ib.book_id "
                + "WHERE ib.member_id = ? AND ib.return_date IS NULL";
        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, memberId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                bookTitles.add(rs.getString("title"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return bookTitles;
    }

    // Check if a book is available (not issued)
    private boolean isBookAvailable(int bookId) {
        String query = "SELECT COUNT(*) FROM issued_books WHERE book_id = ? AND return_date IS NULL";
        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, bookId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getInt(1) == 0; // If no row exists with the book_id and no return_date, it's available
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    // Close the connection when done
    public void closeConnection() {
        try {
            if (conn != null && !conn.isClosed()) {
                conn.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
