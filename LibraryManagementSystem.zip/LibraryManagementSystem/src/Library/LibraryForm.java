/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Library;

/**
 *
 * @author mahesh
 */
import javax.swing.*;
import java.awt.event.*;

public class LibraryForm extends JDialog {

    private JTextField txtBookTitle, txtBookAuthor, txtBookISBN;
    private JTextField txtMemberName, txtMemberEmail;
    private JTextField txtBookIdIssue, txtMemberIdIssue;
    private JButton btnAddBook, btnAddMember, btnIssueBook, btnReturnBook, btnViewIssuedBooks;
    private JList<String> listIssuedBooks;
    private DefaultListModel<String> listModel;

    private Library library;

    public LibraryForm() {
        library = new Library();
        initComponents();
    }

    private void initComponents() {
        setTitle("Library Management System");

        // Book Panel
        JPanel bookPanel = new JPanel();
        bookPanel.setBorder(BorderFactory.createTitledBorder("Add New Book"));

        JLabel lblTitle = new JLabel("Title:");
        txtBookTitle = new JTextField(20);
        JLabel lblAuthor = new JLabel("Author:");
        txtBookAuthor = new JTextField(20);
        JLabel lblISBN = new JLabel("ISBN:");
        txtBookISBN = new JTextField(13);

        btnAddBook = new JButton("Add Book");
        btnAddBook.addActionListener((ActionEvent e) -> addBook());

        bookPanel.add(lblTitle);
        bookPanel.add(txtBookTitle);
        bookPanel.add(lblAuthor);
        bookPanel.add(txtBookAuthor);
        bookPanel.add(lblISBN);
        bookPanel.add(txtBookISBN);
        bookPanel.add(btnAddBook);

        // Member Panel
        JPanel memberPanel = new JPanel();
        memberPanel.setBorder(BorderFactory.createTitledBorder("Add New Member"));

        JLabel lblMemberName = new JLabel("Name:");
        txtMemberName = new JTextField(20);
        JLabel lblMemberEmail = new JLabel("Email:");
        txtMemberEmail = new JTextField(20);

        btnAddMember = new JButton("Add Member");
        btnAddMember.addActionListener((ActionEvent e) -> addMember());

        memberPanel.add(lblMemberName);
        memberPanel.add(txtMemberName);
        memberPanel.add(lblMemberEmail);
        memberPanel.add(txtMemberEmail);
        memberPanel.add(btnAddMember);

        // Issue/Return Panel
        JPanel issuePanel = new JPanel();
        issuePanel.setBorder(BorderFactory.createTitledBorder("Issue/Return Book"));

        JLabel lblBookIdIssue = new JLabel("Book ID:");
        txtBookIdIssue = new JTextField(5);
        JLabel lblMemberIdIssue = new JLabel("Member ID:");
        txtMemberIdIssue = new JTextField(5);

        btnIssueBook = new JButton("Issue Book");
        btnIssueBook.addActionListener((ActionEvent e) -> issueBook());

        btnReturnBook = new JButton("Return Book");
        btnReturnBook.addActionListener((ActionEvent e) -> returnBook());

        issuePanel.add(lblBookIdIssue);
        issuePanel.add(txtBookIdIssue);
        issuePanel.add(lblMemberIdIssue);
        issuePanel.add(txtMemberIdIssue);
        issuePanel.add(btnIssueBook);
        issuePanel.add(btnReturnBook);

        // View Issued Books Panel
        JPanel viewIssuedPanel = new JPanel();
        viewIssuedPanel.setBorder(BorderFactory.createTitledBorder("View Issued Books"));

        JLabel lblMemberId = new JLabel("Member ID:");
        JTextField txtMemberIdView = new JTextField(5);

        btnViewIssuedBooks = new JButton("View Books");
        btnViewIssuedBooks.addActionListener((ActionEvent e) -> {
            int memberId = Integer.parseInt(txtMemberIdView.getText());
            viewIssuedBooks(memberId);
        });

        listModel = new DefaultListModel<>();
        listIssuedBooks = new JList<>(listModel);
        JScrollPane scrollPane = new JScrollPane(listIssuedBooks);

        viewIssuedPanel.add(lblMemberId);
        viewIssuedPanel.add(txtMemberIdView);
        viewIssuedPanel.add(btnViewIssuedBooks);
        viewIssuedPanel.add(scrollPane);

        // Layout
        setLayout(new BoxLayout(getContentPane(), BoxLayout.Y_AXIS));
        add(bookPanel);
        add(memberPanel);
        add(issuePanel);
        add(viewIssuedPanel);

        pack();
        setLocationRelativeTo(null);
    }

    private void addBook() {
        String title = txtBookTitle.getText();
        String author = txtBookAuthor.getText();
        String isbn = txtBookISBN.getText();
        Book book = new Book(0, title, author, isbn);

        if (library.addBook(book)) {
            JOptionPane.showMessageDialog(this, "Book added successfully");
            txtBookTitle.setText("");
            txtBookAuthor.setText("");
            txtBookISBN.setText("");
        } else {
            JOptionPane.showMessageDialog(this, "Error adding book");
        }
    }

    private void addMember() {
        String name = txtMemberName.getText();
        String email = txtMemberEmail.getText();
        Member member = new Member(0, name, email);

        if (library.addMember(member)) {
            JOptionPane.showMessageDialog(this, "Member added successfully");
            txtMemberName.setText("");
            txtMemberEmail.setText("");
        } else {
            JOptionPane.showMessageDialog(this, "Error adding member");
        }
    }

    private void issueBook() {
        int bookId = Integer.parseInt(txtBookIdIssue.getText());
        int memberId = Integer.parseInt(txtMemberIdIssue.getText());

        if (library.issueBook(bookId, memberId)) {
            JOptionPane.showMessageDialog(this, "Book issued successfully");
            txtBookIdIssue.setText("");
            txtMemberIdIssue.setText("");
        } else {
            JOptionPane.showMessageDialog(this, "Error issuing book");
        }
    }

    private void returnBook() {
        int bookId = Integer.parseInt(txtBookIdIssue.getText());
        int memberId = Integer.parseInt(txtMemberIdIssue.getText());

        if (library.returnBook(bookId, memberId)) {
            JOptionPane.showMessageDialog(this, "Book returned successfully");
            txtBookIdIssue.setText("");
            txtMemberIdIssue.setText("");
        } else {
            JOptionPane.showMessageDialog(this, "Error returning book");
        }
    }

    private void viewIssuedBooks(int memberId) {
        listModel.clear();
        java.util.List<String> bookTitles = library.getBooksIssuedToMember(memberId);
        if (bookTitles.isEmpty()) {
            listModel.addElement("No books issued.");
        } else {
            for (String title : bookTitles) {
                listModel.addElement(title);
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new LibraryForm().setVisible(true);
        });
    }
}
